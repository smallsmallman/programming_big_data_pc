#add two numbers together
add <- function (first, second){
  first + second
}

#subtract two numbers
subtract <- function (first, second){
  first - second
  }

#multiply two numbers
multiply <- function (first, second){
  first * second
}

#mean of a list of numbers
mean <- function(list){
  sum(list)/length(list)
}

#get the second number exponent of the first
exponent <- function (first, second){
  first ** second
  }

#square root of one number
sqrt <- function (number){
  number ** 0.5
  }

#square a number
square <- function (number){
  number ** 2
  }

#cube one number
cube  <- function (number){
  number ** 3
  }

#import math and get the sine of a number
sine <- function(number){
  sin(number)
  }

#circumference of a circle
circum <- function (rad){
  2 * pi * rad
}

add(3, 8)
subtract(3, 1)
multiply(8, 9)
mean(c(1, 2, 3))
exponent(10, 2)
sqrt(9)
square(8)
cube(3)
sin(1)
circum(2)