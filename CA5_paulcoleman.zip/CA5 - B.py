#CA5
import math

#1. get the sum of a list of values inside one list
def sum(values): 
	return reduce(lambda x, y: x + y, values)

#2. get the max value within a list
def max(values):
	return reduce(lambda a,b: a if (a > b) else b, values)

#3. get the min value within a list
def min(values):
	return reduce(lambda a,b: a if (a < b) else b, values)

#4. sum the values of one list with the values of another
def add(first, second):
	return map(lambda x, y: x + y, first, second) 

#5. check which values in a list are even 
def is_even(values):
	return filter(lambda x: x%2 == 0, values)

#6. divide a list of values by another
def divide(first, second):
	return map(lambda x, y: x/float(y) if y != 0 else 'nan', first, second)

#7. get the mean of the list of values and produce the values which are greater than the mean
def greater_than_mean_2(values):
	mean = sum(values)/len(values) #calculating the mean before passing it in
	return filter(lambda x: x > mean, values)
	
#8. circumferences of circles
def circum(rad):
	return map(lambda x: x * 2 * math.pi, rad)

#9. list comprehension 
Celsius = [39.2, 36.5, 37.3, 37.8]
Fahrenheit = map(lambda x: (float(9)/5)*x + 32, Celsius)
print 'List Comprehension: ', Fahrenheit

#10. creates fibonacci series based on desired length, skips to next using a generator
def fibonacci(n):
	"""Fibonacci numbers generator, first n"""
	a = 0
	b = 1
	counter = 0
	while True:
		if (counter > n): return
		yield a
		a, b = b, a + b
		counter += 1
		
f = fibonacci(7)
print 'Fibonacci Sequence: '
for x in f: #this will automatically call f.next
	print x,
print 


	
#tests
print 'Sum of Values: ', sum([20, 10, 5, 33, 98])
print 'Max: ', max([20, 10, 5, 33, 98])
print 'Min: ', min([20, 10, 5, 33, 98])
print 'Addition of lists: ', add([20, 10, 5, 33, 98], [54, 5, 23, 21, 2])
print 'Even Values: ', is_even([20, 10, 5, 33, 98])
print 'Division of lists: ', divide([1, 2, 3], [2, 1, 0])
print 'Greater than mean: ', greater_than_mean_2([20, 10, 5, 33, 98])
print 'Circumference of Circle(s):', circum({1, 10, 5, 6, 98})